
import requests
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

POSTCODES_IO_URL = "https://api.postcodes.io/postcodes/"
UKPN_FAULTS_API = "https://ukpowernetworks.opendatasoft.com/api/records/1.0/search/"

@app.post("/lookup")
async def lookup_postcode(postcode: str):
    res = requests.get(f"{POSTCODES_IO_URL}{postcode}")
    if res.status_code != 200:
        raise HTTPException(status_code=400, detail="Invalid postcode")

    data = res.json()
    lat = data["result"]["latitude"]
    lon = data["result"]["longitude"]

    params = {
        "dataset": "faults-and-interruptions",
        "geofilter.distance": f"{lat},{lon},1000",
        "rows": 100
    }
    faults_res = requests.get(UKPN_FAULTS_API, params=params)
    if faults_res.status_code != 200:
        raise HTTPException(status_code=500, detail="Error fetching UKPN data")

    fault_data = faults_res.json()["records"]
    fault_count = len(fault_data)

    if fault_count < 10:
        score = "Low Risk"
    elif fault_count < 30:
        score = "Moderate Risk"
    else:
        score = "High Risk"

    return {
        "postcode": postcode,
        "latitude": lat,
        "longitude": lon,
        "fault_count": fault_count,
        "risk_score": score
    }
